#include "../include/facilityNode.h"

using namespace std;

//Constructors
FacilityNode::FacilityNode(){
    name = "none";
}

FacilityNode::FacilityNode(string newName){
    name = newName;
}

//Setters and getters
void FacilityNode::set_name(string newName){
    name = newName;
}

string FacilityNode::get_name() const{
    return name;
}

const vector<FacilityNode*>& FacilityNode::get_connections() const{
    return connections;
}

//Other methods
bool FacilityNode::has_connection(FacilityNode* in){
    if (in == nullptr) {
        return false;
    }

    for (int i = 0; i < static_cast<int>(connections.size()); i++){
        if (connections.at(i) == in){
            return true;
        }
    }
    return false;
}

bool FacilityNode::add_connection(FacilityNode* in){
    if (in == nullptr || in == this) {
        return false;
    }

    if (!has_connection(in)) {
        //cout << "Connecting node: " << name << " to " << in -> get_name() << endl;
        connections.push_back(in); //Add the target node to our connections
        return true;
    } else {
        return false;
    }
}

void FacilityNode::print(){
    cout << name << " degree(" << connections.size() << ") - ";
    
    if (!connections.empty()){
        for (int i = 0; i < static_cast<int>(connections.size()); i++){
            if (i > 0){
                cout << " | ";
            }
            cout << connections.at(i)->get_name();
        }
    }
    else{
        cout << "no connections";
    }

    cout << endl;
}

bool FacilityNode::operator==(const FacilityNode& other) const {
    return this->name == other.name; // Compare unique identifiers
}